const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Zdjęcie */}
          <div className="order-2 lg:order-1">
            <div className="relative">
              <div className="aspect-[4/5] bg-gray-200 rounded-lg shadow-lg overflow-hidden">
                {/* Placeholder dla zdjęcia profilowego */}
                <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
                  <span className="text-gray-600 text-lg">Zdjęcie profilowe</span>
                </div>
              </div>
              {/* Dekoracyjny element */}
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gray-900 rounded-lg -z-10"></div>
            </div>
          </div>

          {/* Treść */}
          <div className="order-1 lg:order-2">
            <h2 className="text-4xl font-serif font-bold text-gray-900 mb-6">
              O Andrzeju Nestorowiczu
            </h2>
            
            <div className="prose prose-lg text-gray-700 space-y-6">
              <p>
                Andrzej Nestorowicz to kompozytor tworzący muzykę neoklasyczną, która łączy w sobie 
                elegancję tradycyjnych form z nowoczesnością wyrazu. Jego kompozycje charakteryzują się 
                głęboką refleksyjnością i filmową atmosferą, tworząc dźwiękowe pejzaże, które poruszają 
                serca słuchaczy.
              </p>
              
              <p>
                Inspirowany zarówno wielkimi mistrzami klasyki, jak i współczesnymi twórcami muzyki 
                filmowej, Andrzej tworzy utwory, które przekraczają granice gatunków. Jego muzyka 
                opowiada historie bez słów, maluje obrazy dźwiękiem i zaprasza do podróży przez 
                różnorodne krajobrazy emocjonalne.
              </p>
              
              <p>
                Jako artysta wierzy w moc muzyki do łączenia ludzi i przekazywania uniwersalnych 
                emocji. Każda jego kompozycja to starannie wyrzeźbiona opowieść, która pozostaje 
                w pamięci długo po ostatnim dźwięku.
              </p>
            </div>

            {/* Wyróżnienia/Cytaty */}
            <div className="mt-8 p-6 bg-gray-50 rounded-lg border-l-4 border-gray-900">
              <blockquote className="text-gray-700 italic">
                "Muzyka Andrzeja Nestorowicza to poezja zapisana nutami - każdy utwór to podróż 
                przez krajobrazy duszy."
              </blockquote>
              <cite className="text-sm text-gray-600 mt-2 block">— Recenzja muzyczna</cite>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

