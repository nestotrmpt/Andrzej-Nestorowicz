import { Facebook, Instagram, Youtube, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, url: '#' },
    { name: 'Instagram', icon: Instagram, url: '#' },
    { name: 'YouTube', icon: Youtube, url: '#' },
    { name: 'E-mail', icon: Mail, url: 'mailto:kontakt@andrzejnestorowicz.com' }
  ];

  const quickLinks = [
    { name: 'O mnie', href: '#about' },
    { name: 'Koncerty', href: '#concerts' },
    { name: 'Media', href: '#media' },
    { name: 'Sklep', href: '#shop' },
    { name: 'Kontakt', href: '#contact' }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo i opis */}
          <div className="md:col-span-1">
            <h3 className="text-2xl font-serif font-bold mb-4">
              Andrzej Nestorowicz
            </h3>
            <p className="text-gray-300 leading-relaxed mb-6">
              Kompozytor muzyki neoklasycznej, łączącej elegancję tradycji 
              z nowoczesnością wyrazu. Tworzę muzykę, która opowiada historie 
              bez słów.
            </p>
            
            {/* Media społecznościowe */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <a
                    key={social.name}
                    href={social.url}
                    target={social.name === 'E-mail' ? '_self' : '_blank'}
                    rel="noopener noreferrer"
                    className="bg-gray-800 p-2 rounded-lg text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
                    aria-label={social.name}
                  >
                    <IconComponent size={18} />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Szybkie linki */}
          <div className="md:col-span-1">
            <h4 className="text-lg font-semibold mb-4">Nawigacja</h4>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-white transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Kontakt */}
          <div className="md:col-span-1">
            <h4 className="text-lg font-semibold mb-4">Kontakt</h4>
            <div className="space-y-2 text-gray-300">
              <p>kontakt@andrzejnestorowicz.com</p>
              <p>+48 123 456 789</p>
              <p>Warszawa, Polska</p>
            </div>
            
            <div className="mt-6">
              <p className="text-sm text-gray-400 mb-2">Newsletter</p>
              <p className="text-gray-300 text-sm">
                Zapisz się, aby otrzymywać informacje o nowych utworach i koncertach.
              </p>
            </div>
          </div>
        </div>

        {/* Linia podziału */}
        <div className="border-t border-gray-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © {currentYear} Andrzej Nestorowicz. Wszelkie prawa zastrzeżone.
            </p>
            
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Polityka prywatności
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Regulamin
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

