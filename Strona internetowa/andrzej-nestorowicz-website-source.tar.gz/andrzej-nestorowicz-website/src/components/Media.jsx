import { useState } from 'react';
import { Play, Pause, Volume2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const Media = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);

  // Przykładowe zdjęcia - użytkownik będzie mógł je łatwo podmienić
  const galleryImages = [
    {
      id: 1,
      src: '/api/placeholder/400/300',
      alt: 'Koncert w Filharmonii Narodowej',
      title: 'Filharmonia Narodowa, Warszawa'
    },
    {
      id: 2,
      src: '/api/placeholder/400/300',
      alt: 'Sesja nagraniowa w studiu',
      title: 'Sesja nagraniowa'
    },
    {
      id: 3,
      src: '/api/placeholder/400/300',
      alt: 'Występ kameralny',
      title: 'Koncert kameralny'
    },
    {
      id: 4,
      src: '/api/placeholder/400/300',
      alt: 'Praca nad kompozycją',
      title: 'W studiu kompozytorskim'
    },
    {
      id: 5,
      src: '/api/placeholder/400/300',
      alt: 'Koncert plenerowy',
      title: 'Koncert plenerowy'
    },
    {
      id: 6,
      src: '/api/placeholder/400/300',
      alt: 'Współpraca z orkiestrą',
      title: 'Z orkiestrą kameralną'
    }
  ];

  const externalLinks = [
    { name: 'YouTube', url: '#', icon: '🎥' },
    { name: 'Spotify', url: '#', icon: '🎵' },
    { name: 'SoundCloud', url: '#', icon: '🎧' }
  ];

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
    // Tutaj będzie logika odtwarzania audio
  };

  return (
    <section id="media" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-gray-900 mb-4">
            Media
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Posłuchaj moich kompozycji i zobacz zdjęcia z koncertów
          </p>
        </div>

        {/* Odtwarzacz Audio */}
        <div className="bg-gray-50 rounded-lg p-8 mb-16">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-2">
              Kompilacja Utworów
            </h3>
            <p className="text-gray-600">
              Fragmenty najnowszych kompozycji
            </p>
          </div>

          {/* Odtwarzacz */}
          <div className="bg-white rounded-lg p-6 shadow-sm">
            <div className="flex items-center justify-center space-x-4 mb-4">
              <Button
                size="lg"
                onClick={togglePlayback}
                className="bg-gray-900 hover:bg-gray-800 text-white rounded-full w-16 h-16"
              >
                {isPlaying ? <Pause size={24} /> : <Play size={24} />}
              </Button>
            </div>

            {/* Pasek postępu (placeholder) */}
            <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
              <div className="bg-gray-900 h-2 rounded-full w-1/3"></div>
            </div>

            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>1:23</span>
              <div className="flex items-center space-x-2">
                <Volume2 size={16} />
                <span>Kompilacja 2025</span>
              </div>
              <span>4:56</span>
            </div>
          </div>

          {/* Linki zewnętrzne */}
          <div className="flex justify-center space-x-4 mt-6">
            {externalLinks.map((link) => (
              <Button
                key={link.name}
                variant="outline"
                onClick={() => window.open(link.url, '_blank')}
                className="border-gray-300 text-gray-700 hover:bg-gray-100"
              >
                <span className="mr-2">{link.icon}</span>
                {link.name}
                <ExternalLink size={16} className="ml-2" />
              </Button>
            ))}
          </div>
        </div>

        {/* Galeria Zdjęć */}
        <div>
          <h3 className="text-2xl font-serif font-bold text-gray-900 mb-8 text-center">
            Galeria Zdjęć
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((image) => (
              <div
                key={image.id}
                className="relative group cursor-pointer overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => setSelectedImage(image)}
              >
                <div className="aspect-[4/3] bg-gray-200">
                  {/* Placeholder dla zdjęcia */}
                  <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
                    <span className="text-gray-600 text-sm text-center px-4">
                      {image.title}
                    </span>
                  </div>
                </div>
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                  <div className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="text-center">
                      <div className="w-12 h-12 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-2">
                        <Play size={20} />
                      </div>
                      <p className="text-sm font-medium">{image.title}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modal dla powiększonego zdjęcia */}
        {selectedImage && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div className="max-w-4xl max-h-full">
              <div className="bg-gray-200 rounded-lg overflow-hidden">
                <div className="aspect-[4/3] bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
                  <span className="text-gray-600 text-lg">
                    {selectedImage.title}
                  </span>
                </div>
              </div>
              <p className="text-white text-center mt-4 text-lg">
                {selectedImage.title}
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Media;

