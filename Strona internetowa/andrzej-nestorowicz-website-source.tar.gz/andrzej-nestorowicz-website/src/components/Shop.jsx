import { ShoppingCart, ExternalLink, Music, Disc } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const Shop = () => {
  // Przykładowe produkty - użytkownik będzie mógł je łatwo edytować
  const products = [
    {
      id: 1,
      type: 'sheet-music',
      title: 'Refleksje na fortepian',
      description: 'Zbiór 12 miniatur fortepianowych o różnym stopniu trudności.',
      price: '45 PLN',
      image: '/api/placeholder/300/400',
      purchaseLink: '#',
      featured: true
    },
    {
      id: 2,
      type: 'album',
      title: 'Neoklasyczne Podróże',
      description: 'Debiutancki album z najpiękniejszymi kompozycjami.',
      price: '35 PLN',
      image: '/api/placeholder/300/300',
      purchaseLink: '#',
      featured: false
    },
    {
      id: 3,
      type: 'sheet-music',
      title: 'Suita Kameralna op. 1',
      description: 'Suita na kwartet smyczkowy w trzech częściach.',
      price: '60 PLN',
      image: '/api/placeholder/300/400',
      purchaseLink: '#',
      featured: false
    },
    {
      id: 4,
      type: 'album',
      title: 'Muzyka Filmowa Vol. 1',
      description: 'Kolekcja kompozycji stworzonych do filmów i spektakli.',
      price: '40 PLN',
      image: '/api/placeholder/300/300',
      purchaseLink: '#',
      featured: true
    }
  ];

  const getProductIcon = (type) => {
    return type === 'sheet-music' ? <Music size={20} /> : <Disc size={20} />;
  };

  const getProductTypeLabel = (type) => {
    return type === 'sheet-music' ? 'Nuty' : 'Album';
  };

  return (
    <section id="shop" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-gray-900 mb-4">
            Sklep
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Nuty, albumy i bilety na koncerty
          </p>
        </div>

        {/* Wyróżniony koncert */}
        <div className="bg-gradient-to-r from-gray-900 to-gray-700 rounded-lg p-8 mb-16 text-white">
          <div className="text-center">
            <h3 className="text-2xl font-serif font-bold mb-4">
              Najbliższy Koncert
            </h3>
            <p className="text-lg mb-2">Wieczór Muzyki Neoklasycznej</p>
            <p className="text-gray-300 mb-6">15 sierpnia 2025 • Filharmonia Narodowa, Warszawa</p>
            <Button 
              size="lg" 
              className="bg-white text-gray-900 hover:bg-gray-100"
              onClick={() => window.open('#', '_blank')}
            >
              <ExternalLink size={18} className="mr-2" />
              Kup bilety
            </Button>
          </div>
        </div>

        {/* Produkty */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div 
              key={product.id} 
              className={`bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 ${
                product.featured ? 'ring-2 ring-gray-900 ring-opacity-20' : ''
              }`}
            >
              {product.featured && (
                <div className="bg-gray-900 text-white text-xs font-medium px-3 py-1 text-center">
                  POLECANE
                </div>
              )}
              
              {/* Zdjęcie produktu */}
              <div className="aspect-square bg-gray-200 relative">
                <div className="w-full h-full bg-gradient-to-br from-gray-300 to-gray-400 flex items-center justify-center">
                  <div className="text-center text-gray-600">
                    {getProductIcon(product.type)}
                    <p className="text-sm mt-2">{product.title}</p>
                  </div>
                </div>
                
                {/* Typ produktu */}
                <div className="absolute top-3 left-3 bg-white bg-opacity-90 rounded-full px-3 py-1 text-xs font-medium text-gray-700 flex items-center">
                  {getProductIcon(product.type)}
                  <span className="ml-1">{getProductTypeLabel(product.type)}</span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-lg font-serif font-bold text-gray-900 mb-2">
                  {product.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                  {product.description}
                </p>

                <div className="flex items-center justify-between mb-4">
                  <span className="text-xl font-bold text-gray-900">
                    {product.price}
                  </span>
                </div>

                <Button 
                  className="w-full bg-gray-900 hover:bg-gray-800 text-white"
                  onClick={() => window.open(product.purchaseLink, '_blank')}
                >
                  <ShoppingCart size={16} className="mr-2" />
                  Kup teraz
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Informacja dodatkowa */}
        <div className="text-center mt-12 p-6 bg-white rounded-lg shadow-sm">
          <h3 className="text-lg font-serif font-bold text-gray-900 mb-2">
            Szukasz czegoś konkretnego?
          </h3>
          <p className="text-gray-600 mb-4">
            Skontaktuj się ze mną, aby omówić indywidualne zamówienia lub licencje na użycie kompozycji.
          </p>
          <Button 
            variant="outline" 
            className="border-gray-300 text-gray-700 hover:bg-gray-100"
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Skontaktuj się
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Shop;

