import { useState } from 'react';
import { Mail, Phone, MapPin, Send, Facebook, Instagram, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Tutaj będzie logika wysyłania formularza
    console.log('Formularz wysłany:', formData);
    alert('Dziękuję za wiadomość! Odpowiem najszybciej jak to możliwe.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const socialLinks = [
    { name: 'Facebook', icon: Facebook, url: '#', color: 'hover:text-blue-600' },
    { name: 'Instagram', icon: Instagram, url: '#', color: 'hover:text-pink-600' },
    { name: 'YouTube', icon: Youtube, url: '#', color: 'hover:text-red-600' }
  ];

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-serif font-bold text-gray-900 mb-4">
            Kontakt
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Skontaktuj się ze mną w sprawie współpracy, koncertów lub licencji na muzykę
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Formularz kontaktowy */}
          <div>
            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-6">
              Wyślij wiadomość
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Imię i nazwisko
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-colors"
                    placeholder="Jan Kowalski"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Adres e-mail
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-colors"
                    placeholder="jan@example.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                  Temat
                </label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-colors"
                  placeholder="Współpraca muzyczna"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                  Wiadomość
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-gray-900 focus:border-transparent transition-colors resize-vertical"
                  placeholder="Opisz swoją propozycję lub pytanie..."
                />
              </div>

              <Button 
                type="submit" 
                size="lg" 
                className="w-full bg-gray-900 hover:bg-gray-800 text-white"
              >
                <Send size={18} className="mr-2" />
                Wyślij wiadomość
              </Button>
            </form>
          </div>

          {/* Informacje kontaktowe */}
          <div>
            <h3 className="text-2xl font-serif font-bold text-gray-900 mb-6">
              Informacje kontaktowe
            </h3>

            <div className="space-y-6 mb-8">
              <div className="flex items-start space-x-4">
                <div className="bg-gray-100 p-3 rounded-lg">
                  <Mail size={20} className="text-gray-700" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">E-mail</h4>
                  <p className="text-gray-600">kontakt@andrzejnestorowicz.com</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Odpowiadam zwykle w ciągu 24 godzin
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-gray-100 p-3 rounded-lg">
                  <Phone size={20} className="text-gray-700" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">Telefon</h4>
                  <p className="text-gray-600">+48 123 456 789</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Pon-Pt, 9:00-17:00
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="bg-gray-100 p-3 rounded-lg">
                  <MapPin size={20} className="text-gray-700" />
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-1">Lokalizacja</h4>
                  <p className="text-gray-600">Warszawa, Polska</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Dostępny na terenie całego kraju
                  </p>
                </div>
              </div>
            </div>

            {/* Media społecznościowe */}
            <div>
              <h4 className="font-medium text-gray-900 mb-4">Śledź mnie</h4>
              <div className="flex space-x-4">
                {socialLinks.map((social) => {
                  const IconComponent = social.icon;
                  return (
                    <a
                      key={social.name}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`bg-gray-100 p-3 rounded-lg text-gray-700 transition-colors ${social.color}`}
                      aria-label={social.name}
                    >
                      <IconComponent size={20} />
                    </a>
                  );
                })}
              </div>
            </div>

            {/* Dodatkowe informacje */}
            <div className="mt-8 p-6 bg-gray-50 rounded-lg">
              <h4 className="font-medium text-gray-900 mb-2">Współpraca</h4>
              <p className="text-gray-600 text-sm leading-relaxed">
                Jestem otwarty na różne formy współpracy: komponowanie muzyki na zamówienie, 
                występy koncertowe, warsztaty kompozytorskie oraz licencjonowanie istniejących utworów 
                do filmów, reklam i innych projektów medialnych.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;

